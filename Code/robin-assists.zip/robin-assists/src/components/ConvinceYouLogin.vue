<template>
    <div class="convince-you-login">
        <div class="cyl-tekst">
            <h2 class="overtuigd-title">Hebben we je al overtuigd? Download Robin Assistant vandaag en begin anderen te helpen.</h2>
            <a class="login-button" href="https://robinassists.me/dashboard/">Login</a>
        </div>
    </div>
</template>

<style scoped lang="scss">

</style>

<script>
export default {

}
</script>
