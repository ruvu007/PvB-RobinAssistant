<template>
    <div class="copy">
        <slot></slot>
    </div>
</template>

<style scoped lang="scss">

</style>

<script>
export default {
  name: 'Copy'
}
</script>
